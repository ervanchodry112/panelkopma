<?php
echo $this->extend('dashboard/sidebar');
echo $this->section('main');
?>

<main>

</main>

<?= $this->endSection(); ?>